package com.jahannews.app

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.security.MessageDigest

class MainActivity : Activity() {
    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(NewsBridge(), "NewsAndroid")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    inner class NewsBridge {
        @JavascriptInterface
        fun loadNews(category: String, search: String) {
            Thread {
                val result = try {
                    fetchNews(category, search)
                } catch (_: Exception) {
                    JSONObject()
                        .put("error", "دریافت خبر ممکن نشد. اتصال اینترنت را بررسی کنید و دوباره تلاش کنید.")
                        .put("items", JSONArray())
                }
                runOnUiThread {
                    web.evaluateJavascript("window.renderNews(${JSONObject.quote(result.toString())})", null)
                }
            }.start()
        }

        @JavascriptInterface
        fun openLink(url: String) {
            runOnUiThread {
                try {
                    startActivity(
                        android.content.Intent(
                            android.content.Intent.ACTION_VIEW,
                            android.net.Uri.parse(url)
                        )
                    )
                } catch (_: Exception) {
                }
            }
        }
    }

    private fun fetchNews(category: String, search: String): JSONObject {
        val feeds = buildFeedUrls(category, search)
        val pool = Executors.newFixedThreadPool(8)
        val collected = JSONArray()
        val seenKeys = HashSet<String>()

        try {
            val jobs = feeds.map { feedUrl ->
                Callable {
                    try {
                        parseRssFromUrl(feedUrl)
                    } catch (_: Exception) {
                        JSONArray()
                    }
                }
            }
            val results = pool.invokeAll(jobs, 14, TimeUnit.SECONDS)
            for (future in results) {
                if (!future.isDone || future.isCancelled) continue
                try {
                    val arr = future.get()
                    for (i in 0 until arr.length()) {
                        val item = arr.getJSONObject(i)
                        val key = normalizeKey(item.optString("link"), item.optString("title"))
                        if (key.isBlank() || seenKeys.contains(key)) continue
                        seenKeys.add(key)
                        collected.put(item)
                    }
                } catch (_: Exception) {
                }
            }
        } finally {
            pool.shutdownNow()
        }

        // Sort by parsed date descending (newest first)
        val sorted = sortByDateDesc(collected)

        // Keep a larger but bounded batch so the first screen fills quickly.
        val limited = JSONArray()
        val maxItems = 75
        for (i in 0 until minOf(sorted.length(), maxItems)) {
            limited.put(sorted.getJSONObject(i))
        }

        translateItems(limited)
        return JSONObject().put("items", limited).put("error", "")
    }

    private fun buildFeedUrls(category: String, search: String): List<String> {
        val list = ArrayList<String>()
        val q = if (search.isNotBlank()) search.trim() else null

        fun gnews(query: String, whenClause: String? = "1d", hl: String = "en-US", gl: String = "US", ceid: String = "US:en"): String {
            val full = if (whenClause != null) "$query when:$whenClause" else query
            val encoded = URLEncoder.encode(full, "UTF-8")
            return "https://news.google.com/rss/search?q=$encoded&hl=$hl&gl=$gl&ceid=$ceid"
        }

        if (q != null) {
            // Search mode: several recent + broader queries
            list.add(gnews(q, "12h"))
            list.add(gnews(q, "1d"))
            list.add(gnews(q, "2d"))
            list.add(gnews(q, null)) // broader
            // Persian Google News for the same query
            list.add(gnews(q, "1d", "fa", "IR", "IR:fa"))
            return list
        }

        when (category) {
            "سیاست" -> {
                list.add(gnews("world politics OR geopolitics OR diplomacy", "12h"))
                list.add(gnews("world politics OR international relations", "1d"))
                list.add(gnews("US politics OR Europe politics OR Middle East politics", "1d"))
                list.add(gnews("سیاست جهان OR دیپلماسی", "1d", "fa", "IR", "IR:fa"))
                list.add("https://feeds.bbci.co.uk/news/world/rss.xml")
                list.add("https://www.aljazeera.com/xml/rss/all.xml")
            }
            "اقتصاد" -> {
                list.add(gnews("world economy OR global markets OR finance", "12h"))
                list.add(gnews("stock market OR inflation OR central bank", "1d"))
                list.add(gnews("oil price OR currency OR trade", "1d"))
                list.add(gnews("اقتصاد جهان OR بازارهای مالی", "1d", "fa", "IR", "IR:fa"))
                list.add("https://feeds.bbci.co.uk/news/business/rss.xml")
            }
            "فناوری" -> {
                list.add(gnews("technology OR artificial intelligence OR AI OR startup", "12h"))
                list.add(gnews("tech news OR cybersecurity OR semiconductor", "1d"))
                list.add(gnews("Apple OR Google OR Microsoft OR OpenAI", "1d"))
                list.add(gnews("فناوری OR هوش مصنوعی", "1d", "fa", "IR", "IR:fa"))
                list.add("https://feeds.bbci.co.uk/news/technology/rss.xml")
                list.add("https://www.theverge.com/rss/index.xml")
            }
            "جنگ و امنیت" -> {
                list.add(gnews("war OR conflict OR military OR security", "12h"))
                list.add(gnews("Ukraine OR Gaza OR Middle East conflict OR Taiwan", "1d"))
                list.add(gnews("defense OR NATO OR ceasefire", "1d"))
                list.add(gnews("جنگ OR درگیری نظامی OR امنیت", "1d", "fa", "IR", "IR:fa"))
                list.add("https://feeds.bbci.co.uk/news/world/rss.xml")
                list.add("https://www.aljazeera.com/xml/rss/all.xml")
            }
            "ورزش" -> {
                list.add(gnews("world sports OR football OR soccer OR olympics", "12h"))
                list.add(gnews("Premier League OR Champions League OR NBA OR tennis", "1d"))
                list.add(gnews("ورزش جهان OR فوتبال", "1d", "fa", "IR", "IR:fa"))
                list.add("https://feeds.bbci.co.uk/sport/rss.xml")
                list.add("https://www.espn.com/espn/rss/news")
            }
            "علم و سلامت" -> {
                list.add(gnews("science OR health OR medicine OR climate", "12h"))
                list.add(gnews("research OR vaccine OR NASA OR space", "1d"))
                list.add(gnews("علم OR سلامت OR پزشکی", "1d", "fa", "IR", "IR:fa"))
                list.add("https://feeds.bbci.co.uk/news/science_and_environment/rss.xml")
                list.add("https://www.who.int/rss-feeds/news-english.xml")
            }
            "ایران" -> {
                list.add(gnews("Iran news OR Tehran", "12h"))
                list.add(gnews("Iran politics OR Iran economy OR Iran nuclear", "1d"))
                list.add(gnews("ایران", "12h", "fa", "IR", "IR:fa"))
                list.add(gnews("ایران", "1d", "fa", "IR", "IR:fa"))
                list.add("https://feeds.bbci.co.uk/news/world/middle_east/rss.xml")
                list.add("https://www.aljazeera.com/xml/rss/all.xml")
            }
            else -> { // جهان / default
                list.add(gnews("world news OR international news", "12h"))
                list.add(gnews("top stories world", "1d"))
                list.add(gnews("breaking news world", "1d"))
                list.add("https://news.google.com/rss?hl=en-US&gl=US&ceid=US:en")
                list.add("https://feeds.bbci.co.uk/news/world/rss.xml")
                list.add("https://www.aljazeera.com/xml/rss/all.xml")
                list.add(gnews("اخبار جهان", "1d", "fa", "IR", "IR:fa"))
            }
        }
        return list.distinct()
    }

    private fun parseRssFromUrl(feedUrl: String): JSONArray {
        val url = URL(feedUrl)
        val conn = (url.openConnection() as HttpURLConnection).apply {
            connectTimeout = 6500
            readTimeout = 8500
            instanceFollowRedirects = true
            setRequestProperty(
                "User-Agent",
                "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36 JahanNews/1.3"
            )
            setRequestProperty("Accept", "application/rss+xml, application/xml, text/xml, */*")
        }
        return try {
            conn.inputStream.use { parseRss(it) }
        } finally {
            conn.disconnect()
        }
    }

    private fun normalizeKey(link: String, title: String): String {
        val l = link.trim().lowercase(Locale.US)
            .substringBefore("?")
            .removeSuffix("/")
        if (l.isNotBlank() && l != "http" && l != "https") return l
        return title.trim().lowercase(Locale.US).take(120)
    }

    private fun sortByDateDesc(items: JSONArray): JSONArray {
        val list = ArrayList<JSONObject>()
        for (i in 0 until items.length()) list.add(items.getJSONObject(i))
        list.sortByDescending { parseDateMillis(it.optString("date")) }
        val out = JSONArray()
        list.forEach { out.put(it) }
        return out
    }

    private fun parseDateMillis(raw: String): Long {
        if (raw.isBlank()) return 0L
        val patterns = arrayOf(
            "EEE, dd MMM yyyy HH:mm:ss Z",
            "EEE, dd MMM yyyy HH:mm:ss z",
            "yyyy-MM-dd'T'HH:mm:ssXXX",
            "yyyy-MM-dd'T'HH:mm:ss'Z'",
            "yyyy-MM-dd HH:mm:ss"
        )
        for (p in patterns) {
            try {
                val sdf = SimpleDateFormat(p, Locale.US)
                sdf.timeZone = TimeZone.getTimeZone("UTC")
                val d = sdf.parse(raw.trim())
                if (d != null) return d.time
            } catch (_: Exception) {
            }
        }
        return 0L
    }

    private fun translationCache() = getSharedPreferences("jahan_translation_cache", MODE_PRIVATE)

    private fun cacheKey(title: String, description: String): String {
        val raw = (title + "\n" + description).toByteArray(Charsets.UTF_8)
        val digest = MessageDigest.getInstance("SHA-256").digest(raw)
        return "t_" + digest.joinToString("") { "%02x".format(it) }
    }

    private fun translateItems(items: JSONArray) {
        if (items.length() == 0) return
        val cache = translationCache()
        val pool = Executors.newFixedThreadPool(10)
        try {
            val jobs = (0 until items.length()).map { index ->
                Callable {
                    val item = items.getJSONObject(index)
                    val title = item.optString("title")
                    val description = item.optString("description")
                    val key = cacheKey(title, description)
                    val cached = cache.getString(key, null)
                    if (cached != null) {
                        try {
                            val pair = JSONObject(cached)
                            item.put("originalTitle", title)
                            item.put("originalDescription", description)
                            item.put("title", pair.optString("title", title))
                            item.put("description", pair.optString("description", description))
                            item.put("translationOk", true)
                        } catch (_: Exception) { }
                        return@Callable
                    }

                    val translatedTitle: String
                    val translatedDescription: String
                    if (looksPersian(title) && (description.isBlank() || looksPersian(description))) {
                        translatedTitle = title
                        translatedDescription = description
                    } else {
                        // One translation request per article instead of two, reducing latency.
                        val combined = title + "\n\nJAHANNEWS_DESC\n\n" + description
                        val translated = translateToPersian(combined)
                        if (translated != null) {
                            val parts = translated.split("JAHANNEWS_DESC", limit = 2)
                            translatedTitle = parts.getOrNull(0)?.trim()?.ifBlank { title } ?: title
                            translatedDescription = parts.getOrNull(1)?.trim()?.ifBlank { description } ?: description
                        } else {
                            translatedTitle = title
                            translatedDescription = description
                        }
                    }
                    item.put("originalTitle", title)
                    item.put("originalDescription", description)
                    item.put("title", translatedTitle)
                    item.put("description", translatedDescription)
                    item.put("translationOk", translatedTitle != title || looksPersian(title))
                    if (translatedTitle != title || translatedDescription != description) {
                        cache.edit().putString(key, JSONObject()
                            .put("title", translatedTitle)
                            .put("description", translatedDescription).toString()).apply()
                    }
                }
            }
            // Do not hold the UI for a long translation tail; untranslated items retain original text.
            pool.invokeAll(jobs, 14, TimeUnit.SECONDS)
        } finally {
            pool.shutdownNow()
        }
    }

    private fun looksPersian(text: String): Boolean {
        if (text.isBlank()) return false
        var persian = 0
        var letters = 0
        for (c in text) {
            if (c.isLetter()) {
                letters++
                if (c in '\u0600'..'\u06FF') persian++
            }
        }
        return letters > 0 && persian * 2 >= letters
    }

    private fun translateToPersian(text: String): String? {
        if (text.isBlank()) return ""
        val encoded = URLEncoder.encode(text.take(1600), "UTF-8")
        val url = URL("https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=fa&dt=t&q=$encoded")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            connectTimeout = 5000
            readTimeout = 7000
            setRequestProperty("User-Agent", "Mozilla/5.0")
        }
        return try {
            val body = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val root = JSONArray(body)
            val segments = root.optJSONArray(0) ?: return null
            val out = StringBuilder()
            for (i in 0 until segments.length()) {
                val segment = segments.optJSONArray(i)
                if (segment != null) out.append(segment.optString(0))
            }
            out.toString().trim().ifBlank { null }
        } catch (_: Exception) {
            null
        } finally {
            conn.disconnect()
        }
    }

    private fun parseRss(stream: InputStream): JSONArray {
        val parser = XmlPullParserFactory.newInstance().newPullParser()
        parser.setInput(stream, "UTF-8")
        val out = JSONArray()
        var event = parser.eventType
        var inItem = false
        var title = ""
        var link = ""
        var source = ""
        var date = ""
        var description = ""
        while (event != XmlPullParser.END_DOCUMENT && out.length() < 40) {
            when (event) {
                XmlPullParser.START_TAG -> {
                    val name = parser.name?.lowercase(Locale.US) ?: ""
                    when (name) {
                        "item", "entry" -> {
                            inItem = true
                            title = ""; link = ""; source = ""; date = ""; description = ""
                        }
                        "title" -> if (inItem) title = parser.nextText()
                        "link" -> if (inItem) {
                            // Atom may have href attribute
                            val href = parser.getAttributeValue(null, "href")
                            link = if (!href.isNullOrBlank()) href else parser.nextText()
                        }
                        "source" -> if (inItem) source = parser.nextText()
                        "pubdate", "published", "updated", "dc:date" -> if (inItem) date = parser.nextText()
                        "description", "summary", "content" -> if (inItem) {
                            val t = parser.nextText()
                            if (t.length > description.length) description = t
                        }
                        "guid" -> if (inItem && link.isBlank()) {
                            val t = parser.nextText()
                            if (t.startsWith("http")) link = t
                        }
                    }
                }
                XmlPullParser.END_TAG -> {
                    val name = parser.name
                    if ((name.equals("item", true) || name.equals("entry", true)) && inItem) {
                        if (title.isNotBlank() && link.isNotBlank()) {
                            // Try extract source from Google News title "Title - Source"
                            var finalSource = clean(source)
                            var finalTitle = clean(title)
                            if (finalSource.isBlank() && finalTitle.contains(" - ")) {
                                val parts = finalTitle.split(" - ")
                                if (parts.size >= 2) {
                                    finalSource = parts.last().trim()
                                    finalTitle = parts.dropLast(1).joinToString(" - ").trim()
                                }
                            }
                            if (finalSource.isBlank()) finalSource = "منبع در فید مشخص نشده"
                            out.put(
                                JSONObject()
                                    .put("title", finalTitle)
                                    .put("source", finalSource)
                                    .put("date", clean(date))
                                    .put("description", clean(description).take(600))
                                    .put("link", link.trim())
                            )
                        }
                        inItem = false
                    }
                }
            }
            event = parser.next()
        }
        return out
    }

    private fun clean(value: String): String = value
        .replace(Regex("<[^>]*>"), " ")
        .replace("&nbsp;", " ")
        .replace("&amp;", "&")
        .replace("&quot;", "\"")
        .replace("&#39;", "'")
        .replace("&lt;", "<")
        .replace("&gt;", ">")
        .replace(Regex("\\s+"), " ")
        .trim()
}
