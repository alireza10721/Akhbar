package com.jahannews.app

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.io.InputStream

class MainActivity : Activity() {
    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(NewsBridge(), "NewsAndroid")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    inner class NewsBridge {
        @JavascriptInterface
        fun loadNews(category: String, search: String) {
            Thread {
                val result = try { fetchNews(category, search) }
                catch (_: Exception) {
                    JSONObject().put("error", "دریافت خبر ممکن نشد. اینترنت را بررسی کنید و دوباره تلاش کنید.")
                        .put("items", JSONArray())
                }
                runOnUiThread {
                    web.evaluateJavascript("window.renderNews(${JSONObject.quote(result.toString())})", null)
                }
            }.start()
        }
        @JavascriptInterface
        fun openLink(url: String) {
            runOnUiThread {
                try { startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url))) }
                catch (_: Exception) {}
            }
        }
    }

    private fun fetchNews(category: String, search: String): JSONObject {
        val query = if (search.isNotBlank()) search else when (category) {
            "سیاست" -> "world politics"
            "اقتصاد" -> "world economy finance"
            "فناوری" -> "technology science"
            "جنگ و امنیت" -> "war conflict security"
            "ورزش" -> "world sports"
            "علم و سلامت" -> "science health"
            "ایران" -> "Iran news"
            else -> "world news"
        }
        val encoded = URLEncoder.encode(query, "UTF-8")
        val url = URL("https://news.google.com/rss/search?q=$encoded&hl=fa&gl=IR&ceid=IR:fa")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000
            readTimeout = 15000
            setRequestProperty("User-Agent", "Mozilla/5.0 JahanNews/1.1")
        }
        try {
            conn.inputStream.use { return JSONObject().put("items", parseRss(it)).put("error", "") }
        } finally { conn.disconnect() }
    }

    private fun parseRss(stream: InputStream): JSONArray {
        val parser = XmlPullParserFactory.newInstance().newPullParser()
        parser.setInput(stream, "UTF-8")
        val out = JSONArray()
        var event = parser.eventType
        var inItem = false
        var title = ""; var link = ""; var source = ""; var date = ""; var description = ""
        while (event != XmlPullParser.END_DOCUMENT && out.length() < 40) {
            when (event) {
                XmlPullParser.START_TAG -> when (parser.name.lowercase()) {
                    "item" -> { inItem = true; title = ""; link = ""; source = ""; date = ""; description = "" }
                    "title" -> if (inItem) title = parser.nextText()
                    "link" -> if (inItem) link = parser.nextText()
                    "source" -> if (inItem) source = parser.nextText()
                    "pubdate" -> if (inItem) date = parser.nextText()
                    "description" -> if (inItem) description = parser.nextText()
                }
                XmlPullParser.END_TAG -> if (parser.name.equals("item", true) && inItem) {
                    if (title.isNotBlank() && link.isNotBlank()) {
                        out.put(JSONObject().put("title", clean(title))
                            .put("source", clean(source.ifBlank { "منبع در فید مشخص نشده" }))
                            .put("date", clean(date))
                            .put("description", clean(description).take(500))
                            .put("link", link))
                    }
                    inItem = false
                }
            }
            event = parser.next()
        }
        return out
    }

    private fun clean(value: String): String = value
        .replace(Regex("<[^>]*>"), " ").replace("&nbsp;", " ").replace("&amp;", "&")
        .replace("&quot;", "\"").replace("&#39;", "'").replace(Regex("\\s+"), " ").trim()
}
