package com.jahannews.app

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.io.InputStream
import java.util.concurrent.Callable
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(NewsBridge(), "NewsAndroid")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    inner class NewsBridge {
        @JavascriptInterface
        fun loadNews(category: String, search: String) {
            Thread {
                val result = try { fetchNews(category, search) }
                catch (_: Exception) {
                    JSONObject().put("error", "دریافت خبر ممکن نشد. اتصال اینترنت را بررسی کنید و دوباره تلاش کنید.")
                        .put("items", JSONArray())
                }
                runOnUiThread {
                    web.evaluateJavascript("window.renderNews(${JSONObject.quote(result.toString())})", null)
                }
            }.start()
        }
        @JavascriptInterface
        fun openLink(url: String) {
            runOnUiThread {
                try { startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url))) }
                catch (_: Exception) {}
            }
        }
    }

    private fun fetchNews(category: String, search: String): JSONObject {
        val query = if (search.isNotBlank()) search else when (category) {
            "سیاست" -> "world politics"
            "اقتصاد" -> "world economy finance"
            "فناوری" -> "technology science"
            "جنگ و امنیت" -> "war conflict security"
            "ورزش" -> "world sports"
            "علم و سلامت" -> "science health"
            "ایران" -> "Iran news"
            else -> "world news"
        }
        val encoded = URLEncoder.encode(query, "UTF-8")
        val url = URL("https://news.google.com/rss/search?q=$encoded&hl=en-US&gl=US&ceid=US:en")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000
            readTimeout = 15000
            setRequestProperty("User-Agent", "Mozilla/5.0 JahanNews/1.2")
        }
        try {
            conn.inputStream.use {
                val items = parseRss(it)
                translateItems(items)
                return JSONObject().put("items", items).put("error", "")
            }
        } finally { conn.disconnect() }
    }

    // Translate titles and short feed descriptions to Persian using Google's public
    // web translation endpoint. This endpoint is free to access but is not an SLA-backed API.
    private fun translateItems(items: JSONArray) {
        val pool = Executors.newFixedThreadPool(5)
        try {
            val jobs = (0 until items.length()).map { index ->
                Callable {
                    val item = items.getJSONObject(index)
                    val title = item.optString("title")
                    val description = item.optString("description")
                    val translatedTitle = translateToPersian(title)
                    val translatedDescription = if (description.isNotBlank()) translateToPersian(description) else ""
                    synchronized(items) {
                        item.put("originalTitle", title)
                        item.put("originalDescription", description)
                        item.put("title", translatedTitle ?: title)
                        item.put("description", translatedDescription ?: description)
                        item.put("translationOk", translatedTitle != null)
                    }
                }
            }
            pool.invokeAll(jobs).forEach { it.get() }
        } finally {
            pool.shutdown()
        }
    }

    private fun translateToPersian(text: String): String? {
        if (text.isBlank()) return ""
        val encoded = URLEncoder.encode(text.take(1800), "UTF-8")
        val url = URL("https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=fa&dt=t&q=$encoded")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            connectTimeout = 10000
            readTimeout = 12000
            setRequestProperty("User-Agent", "Mozilla/5.0")
        }
        return try {
            val body = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val root = JSONArray(body)
            val segments = root.optJSONArray(0) ?: return null
            val out = StringBuilder()
            for (i in 0 until segments.length()) {
                val segment = segments.optJSONArray(i)
                if (segment != null) out.append(segment.optString(0))
            }
            out.toString().trim().ifBlank { null }
        } catch (_: Exception) {
            null
        } finally {
            conn.disconnect()
        }
    }

    private fun parseRss(stream: InputStream): JSONArray {
        val parser = XmlPullParserFactory.newInstance().newPullParser()
        parser.setInput(stream, "UTF-8")
        val out = JSONArray()
        var event = parser.eventType
        var inItem = false
        var title = ""; var link = ""; var source = ""; var date = ""; var description = ""
        while (event != XmlPullParser.END_DOCUMENT && out.length() < 25) {
            when (event) {
                XmlPullParser.START_TAG -> when (parser.name.lowercase()) {
                    "item" -> { inItem = true; title = ""; link = ""; source = ""; date = ""; description = "" }
                    "title" -> if (inItem) title = parser.nextText()
                    "link" -> if (inItem) link = parser.nextText()
                    "source" -> if (inItem) source = parser.nextText()
                    "pubdate" -> if (inItem) date = parser.nextText()
                    "description" -> if (inItem) description = parser.nextText()
                }
                XmlPullParser.END_TAG -> if (parser.name.equals("item", true) && inItem) {
                    if (title.isNotBlank() && link.isNotBlank()) {
                        out.put(JSONObject().put("title", clean(title))
                            .put("source", clean(source.ifBlank { "منبع در فید مشخص نشده" }))
                            .put("date", clean(date))
                            .put("description", clean(description).take(500))
                            .put("link", link))
                    }
                    inItem = false
                }
            }
            event = parser.next()
        }
        return out
    }

    private fun clean(value: String): String = value
        .replace(Regex("<[^>]*>"), " ").replace("&nbsp;", " ").replace("&amp;", "&")
        .replace("&quot;", "\"").replace("&#39;", "'").replace(Regex("\\s+"), " ").trim()
}
