plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

dependencies {
    implementation("org.jsoup:jsoup:1.18.3")
}

android {
    namespace = "com.jahannews.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.jahannews.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 8
        versionName = "1.8"
    }

    // Keep Java and Kotlin bytecode targets aligned.
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}
