plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.jahannews.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.jahannews.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 6
        versionName = "1.6"
    }

    // Keep Java and Kotlin bytecode targets aligned.
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}
